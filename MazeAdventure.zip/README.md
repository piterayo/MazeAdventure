# Maze Adventure
Game developed for CPCRetroDev 2016 contest.

    Compilation instructions:
        -Write make while in project directory (You need CPCtelera to compile)
        
    Developed by:                       Twitter:
        Idea and Coding: 
            Albert Sirvent Jerez        @piterayo
        Graphics: 
            Alejandro Padilla Lozoya    @Sylph_R
        Music:
            Carlos Blaya Cases
                        
    Created using:
    
        -CPCtelera 1.4 
            http://lronaldo.github.io/cpctelera/files/authors-txt.html
            
        -Arkos Trackers
            http://julien-nevo.com/arkos/members.html
            
        -Gimp
            https://www.gimp.org/about/
            
        -Paint.NET
            http://www.getpaint.net/license.html
        
    Camelot Warriors reference:
        Sprite of Camelot Warriors easter egg based on Camelot Warriors main character.
        Type CAMELOT WARRIORS as save code to activate the easter egg.