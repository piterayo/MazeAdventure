
#ifndef STATE_CREDITS_H
#define STATE_CREDITS_H

#include <cpctelera.h>

extern void state_credits_enter();

extern void state_credits_return();

extern void state_credits_input();

extern void state_credits_update();

extern void state_credits_render();

extern void state_credits_exit();



#endif