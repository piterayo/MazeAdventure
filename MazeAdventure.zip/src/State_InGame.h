
#ifndef STATE_INGAME_H
#define STATE_INGAME_H


extern void state_ingame_enter();

extern void state_ingame_return();

extern void state_ingame_input();

extern void state_ingame_update();

extern void state_ingame_render();

extern void state_ingame_exit();


#endif