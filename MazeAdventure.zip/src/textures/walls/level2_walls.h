#ifndef _level2_walls_H_
#define _level2_walls_H_

#include <types.h>

#define level2_walls_LENGTH 2094

extern const u8 const level2_walls[2094];

#endif
