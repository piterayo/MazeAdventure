#ifndef _level1_walls_H_
#define _level1_walls_H_

#include <types.h>

#define level1_walls_LENGTH 2133

extern const u8 const level1_walls[2133];

#endif
