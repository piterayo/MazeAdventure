#ifndef _level0_walls_H_
#define _level0_walls_H_

#include <types.h>

#define level0_walls_LENGTH 1469

extern const u8 const level0_walls[1469];

#endif
