#ifndef _level3_walls_H_
#define _level3_walls_H_

#include <types.h>

#define level3_walls_LENGTH 1783

extern const u8 const level3_walls[1783];

#endif
