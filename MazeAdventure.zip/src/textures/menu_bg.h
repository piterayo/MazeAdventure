#ifndef _menu_bg_H_
#define _menu_bg_H_

#include <types.h>

#define menu_bg_LENGTH 1521

extern const u8 const menu_bg[1521];

#endif
