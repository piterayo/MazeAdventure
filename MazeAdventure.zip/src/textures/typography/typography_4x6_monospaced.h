#ifndef _typography_4x6_monospaced_H_
#define _typography_4x6_monospaced_H_

#include <types.h>

#define typography_4x6_monospaced_LENGTH 150

extern const u8 const typography_4x6_monospaced[150];

#endif
