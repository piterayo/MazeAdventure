#ifndef _level3_enemies_H_
#define _level3_enemies_H_

#include <types.h>

#define level3_enemies_LENGTH 183

extern const u8 const level3_enemies[183];

#endif
