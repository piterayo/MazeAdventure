#ifndef _level1_enemies_H_
#define _level1_enemies_H_

#include <types.h>

#define level1_enemies_LENGTH 171

extern const u8 const level1_enemies[171];

#endif
