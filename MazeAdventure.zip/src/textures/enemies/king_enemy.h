#ifndef _king_enemy_H_
#define _king_enemy_H_

#include <types.h>

#define king_enemy_LENGTH 184

extern const u8 const king_enemy[184];

#endif
