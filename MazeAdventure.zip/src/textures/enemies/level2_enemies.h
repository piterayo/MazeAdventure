#ifndef _level2_enemies_H_
#define _level2_enemies_H_

#include <types.h>

#define level2_enemies_LENGTH 123

extern const u8 const level2_enemies[123];

#endif
