#ifndef _level0_enemies_H_
#define _level0_enemies_H_

#include <types.h>

#define level0_enemies_LENGTH 132

extern const u8 const level0_enemies[132];

#endif
