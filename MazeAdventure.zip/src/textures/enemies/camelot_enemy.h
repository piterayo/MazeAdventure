#ifndef _camelot_enemy_H_
#define _camelot_enemy_H_

#include <types.h>

#define camelot_enemy_LENGTH 123

extern const u8 const camelot_enemy[123];

#endif
