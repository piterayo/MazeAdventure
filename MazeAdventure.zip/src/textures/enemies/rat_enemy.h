#ifndef _rat_enemy_H_
#define _rat_enemy_H_

#include <types.h>

#define rat_enemy_LENGTH 108

extern const u8 const rat_enemy[108];

#endif
