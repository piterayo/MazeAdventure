#ifndef _items_tileset_H_
#define _items_tileset_H_

#include <types.h>

#define items_tileset_LENGTH 330

extern const u8 const items_tileset[330];

#endif
