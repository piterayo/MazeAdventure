
#ifndef STATE_LOADGAME_H
#define STATE_LOADGAME_H

#include <cpctelera.h>

extern void state_loadgame_enter();

extern void state_loadgame_return();

extern void state_loadgame_input();

extern void state_loadgame_update();

extern void state_loadgame_render();

extern void state_loadgame_exit();


#endif