
#ifndef STATE_MAINMENU_H
#define STATE_MAINMENU_H


extern void state_mainmenu_enter();

extern void state_mainmenu_return();

extern void state_mainmenu_input();

extern void state_mainmenu_update();

extern void state_mainmenu_render();

extern void state_mainmenu_exit();


#endif