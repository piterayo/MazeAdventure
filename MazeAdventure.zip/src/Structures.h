
#ifndef STRUCTURES_H
#define STRUCTURES_H

#include <cpctelera.h>

typedef struct{
    i8 x;
    i8 y;
} Vec2i;

typedef struct{
    u8 x;
    u8 y;
} Vec2u;



#endif