
#ifndef STATE_VICTORY_H
#define STATE_VICTORY_H

#include <cpctelera.h>

extern void state_victory_enter();

extern void state_victory_return();

extern void state_victory_input();

extern void state_victory_update();

extern void state_victory_render();

extern void state_victory_exit();


#endif