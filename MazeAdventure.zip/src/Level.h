
#ifndef LEVEL_H
#define LEVEL_H

#include <cpctelera.h>

extern void level_set_level(u8 l) ;

extern u8 level_get_level();

extern void level_load_level();

extern void level_init_palettes();

// extern void setMenuPalette();

#endif