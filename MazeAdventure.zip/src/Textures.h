

#ifndef TEXTURES_H
#define TEXTURES_H


// extern u8** const theme_textures[4];

extern void uncompress_theme_textures(u8 level) ;

extern void uncompress_enemy_textures(u8 level) ;

// extern void uncompress_shared_textures();


#endif