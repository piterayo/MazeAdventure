
#ifndef STATE_OPTIONS_H
#define STATE_OPTIONS_H

#include <cpctelera.h>

extern void state_options_enter();

extern void state_options_return();

extern void state_options_input();

extern void state_options_update();

extern void state_options_render();

extern void state_options_exit();


#endif