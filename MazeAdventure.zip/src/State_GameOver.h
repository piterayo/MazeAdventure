
#ifndef STATE_GAMEOVER_H
#define STATE_GAMEOVER_H

#include <cpctelera.h>

extern void state_gameover_enter();

extern void state_gameover_return();

extern void state_gameover_input();

extern void state_gameover_update();

extern void state_gameover_render();

extern void state_gameover_exit();


#endif