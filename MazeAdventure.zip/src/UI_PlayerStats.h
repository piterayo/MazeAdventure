
#ifndef UIPLAYERSTATS_H
#define UIPLAYERSTATS_H

#include <cpctelera.h>

extern void ui_playerstats_render_all();

extern void ui_playerstats_render_hp();

extern void ui_playerstats_render_attack();

extern void ui_playerstats_render_defense();

extern void ui_playerstats_render_potions();

extern void ui_playerstats_render_scrolls();

extern void ui_playerstats_render_key();


#endif