#ifndef _MUSIC_H_
#define _MUSIC_H_

#include <types.h>

extern __at(0x0040) const u8 const GameMusic[206];

#endif
