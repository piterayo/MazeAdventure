
#ifndef STATE_PAUSEMENU_H
#define STATE_PAUSEMENU_H


extern void state_pausemenu_enter();

extern void state_pausemenu_return();

extern void state_pausemenu_input();

extern void state_pausemenu_update();

extern void state_pausemenu_render();

extern void state_pausemenu_exit();


#endif